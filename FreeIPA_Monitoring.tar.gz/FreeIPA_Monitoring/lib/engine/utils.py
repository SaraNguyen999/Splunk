from unittest import result
from const import APP_INDEX, FREEIPA_ACTION_RESULTS_SOURCETYPE
from splunk_handler.interact import splunk_query, get_search_result
from ldap3 import *

def get_disable_user(service, freeipa_host, user):

    query = f"""
        |search index={APP_INDEX} sourcetype={FREEIPA_ACTION_RESULTS_SOURCETYPE} 
            freeipa_host="{freeipa_host}"
            user="{user}"
            earliest=0 latest=now
        | table user
    """

    job = splunk_query(service, query)
    results = get_search_result(job)
    return [item["user"] for item in results]


def is_disable(service, freeipa_host, user):

    blocked_users = get_disable_user(service, freeipa_host, user)
    return True if user in blocked_users else False

def is_user(conn,user):
    search_filter = "(displayName={0}*)"
    results=0
    conn.search(search_base='CN=Users,DC=htc,DC=com',
        search_filter=search_filter.format(user),
        search_scope=SUBTREE,
        attributes=ALL_ATTRIBUTES,
        get_operational_attributes=True)
    for entry in conn.response:
        results+=1
    return results