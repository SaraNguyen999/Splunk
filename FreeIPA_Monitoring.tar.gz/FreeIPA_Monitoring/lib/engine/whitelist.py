from splunk_handler.interact import splunk_query, get_search_result
from const import APP_INDEX, ACTIVE_DIRECTORY_WHITELIST_SOURCETYPE


def get_whitelist(service):
    query = f"""
        | search index={APP_INDEX} sourcetype={ACTIVE_DIRECTORY_WHITELIST_SOURCETYPE} earliest=0 latest=now
        | stats values(user) as user by ad_host
    """

    job = splunk_query(service, query)

    whitelist = get_search_result(job)

    job.cancel()

    return whitelist


def delete_whitelist_record(service, ad_host, user, expire_in):
    query = f"""
        | search index={APP_INDEX} sourcetype={ACTIVE_DIRECTORY_WHITELIST_SOURCETYPE} 
        ad_host={ad_host} user={user} expire_in={expire_in} earliest=0 latest=now
        | delete
    """
    job = splunk_query(service, query)

    result = get_search_result(job)

    job.cancel()

    return result


def is_whitelist(service, host, user):
    whitelist = get_whitelist(service)

    for item in whitelist:

        if item["ad_host"] == host:
            if isinstance(item["user"], list) and user in item["user"]:
                return True
            if isinstance(item["user"], str) and user == item["user"]:
                return True

    return False


def refresh_whitelist(service):
    query = f"""
        | search index={APP_INDEX} sourcetype={ACTIVE_DIRECTORY_WHITELIST_SOURCETYPE} earliest=0 latest=now
        | where relative_time(_time, expire_in) < now() and expire_in!=0
        | delete
    """

    job = splunk_query(service, query)

    result = get_search_result(job)

    job.cancel()

    return result
