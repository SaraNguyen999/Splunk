from const import  REALM

import splunklib.results as results
import splunklib.client as client
import re


def get_credential(service, account_name):
    secrets = service.storage_passwords
    for secret in secrets:
        if secret.content.username == account_name and secret.content.realm == REALM:
            return secret.clear_password
    return None

def splunk_query(service, query):
    jobs = service.jobs
    kwargs_blockingsearch = {"exec_mode": "blocking"}
    job = jobs.create(query, **kwargs_blockingsearch)
    return job


def get_search_result(job):
    return [elemt for elemt in results.ResultsReader(job.results())]
