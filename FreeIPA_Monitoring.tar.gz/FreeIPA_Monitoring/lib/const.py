DEFAULT_VERIFY = 0
DEFAULT_TIMEOUT = 30
DEFAULT_PORT = 389
DEFAULT_TAGS = "splunk blocked"
DEFAULT_DESCRIPTION = "splunk_ta created"
DEFAULT_USER="uid=sara,cn=users,cn=accounts,dc=randd,dc=com"
DO_NOT_GET = "``splunk_cred_sep``S``splunk_cred_sep``P``splunk_cred_sep``L``splunk_cred_sep``U``splunk_cred_sep``N``splunk_cred_sep``K``splunk_cred_sep``"
USERNAME_PATTERN = "{account_name}``splunk_cred_sep``(\\d+)"
REALM = "FreeIPA"
SPLUNK_APP = "/opt/splunk/etc/apps/FreeIPA_Monitoring/"
APP_INDEX = "freeipa"
FREEIPA_ACTION_RESULTS_SOURCETYPE = "freeipa_source"
DEFAULT_TELEGRAM_TOKEN="5792839885:AAHFlyAeNqr1ZZJsf0BlupEP3fmAKK0dgpw"
DEFAULT_TELEGRAM_CHATID=["-840256581"]
import os

SPLUNK_HOME = os.getenv("SPLUNK_HOME")
# DEFAULT_CSV_WEBHOOK= (
#     f"{SPLUNK_HOME}/etc/apps/AD-Adaptive-Response/lookups/msteamwebhooks.csv"
# )
COMMAND_SERVER="http://192.168.22.144:44444"
NOTIFY_SERVER="http://192.168.135.170:40000"