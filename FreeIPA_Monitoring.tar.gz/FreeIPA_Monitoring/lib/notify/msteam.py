import pymsteams
import urllib.parse
from datetime import datetime
from notify.readcsv import *
from const import *
import json

def msteam( host, user,domain, status, webhook, token,subtitle,group,result_link):
    #url_webhook="https://thctechgroup.webhook.office.com/webhookb2/bb16601c-e361-4dd2-a765-d3e91813f61f@c721557d-32d7-4cbd-9aad-5ba096cd7683/IncomingWebhook/ef99037f9de046f58d328001a8659a8d/183db949-d3e9-4471-85a6-381466ccba6d"

    url =DEFAULT_CSV_WEBHOOK
    url_webhook=readcsv(url, webhook)

    myTeamsMessage = pymsteams.connectorcard(
        url_webhook
    )
    myMessageSection = pymsteams.cardsection()
    myTeamsMessage.summary("Ldap")

    myTeamsMessage.color("#0000FF")
    # Activity Elements
    myMessageSection.activityTitle("Splunk LDAP Action")
    myTeamsPotentialAction3 = pymsteams.potentialaction(_name="Change Status")

    actionbutton=(
        f'''{NGROK}/action_splunk/'''
    )
    myMessageSection.activityImage(
        "https://cdn.pixabay.com/photo/2018/05/08/21/29/windows-3384024_960_720.png"
    )
    data = {}
    data["host"] = host
    data["user"] = user
    data["domain"] = domain
    data["token"] =token
    data["group"] =group
    data["webhook"]=webhook

    if status == "disable":
        data["status"] = "disable"
        body=json.dumps(data)
        myMessageSection.activitySubtitle(subtitle)
        myMessageSection.text(f"User này đã bị disable và được thêm vào LDAP Group <b>{group}</b>.")
        myTeamsPotentialAction3.addAction_custom("HttpPost", "Enable", actionbutton,body)

    else:
        data["status"] = "enable"
        body=json.dumps(data)
        myMessageSection.activitySubtitle(subtitle)
        myMessageSection.text("User này xuất hiện trong cảnh báo nhưng hành động chưa được thực thi .")
        myTeamsPotentialAction3.addAction_custom("HttpPost", "Disable", actionbutton,body)

    potential_add_whitelist_user = pymsteams.potentialaction(
        _name="Add user into whitelist")
    potential_add_whitelist_user.choices.addChoices("1 day", "+24h")
    potential_add_whitelist_user.choices.addChoices("3 days", "+72h")
    potential_add_whitelist_user.choices.addChoices("7 days", "+168h")
    potential_add_whitelist_user.choices.addChoices("No expire", "0")
    potential_add_whitelist_user.addInput(
        "MultichoiceInput", "list", "Select time expire", False)

    payload = json.dumps({"expire": "{{list.value}}", "user": user, "host":host})
    potential_add_whitelist_user.addAction_custom("HttpPost", "Submit",f'''{NGROK}/add_white_list/''',payload)
    # Facts are key value pairs displayed in a list.
    myMessageSection.addFact("User name:", user)
    myMessageSection.addFact("Host name:", host)
    myMessageSection.addFact("Date:",datetime.now().strftime("%d/%m/%Y"))
    myMessageSection.addFact("Time:",datetime.now().strftime("%H:%M:%S"))
    
    # Section Text
    # Section Images
    myMessageSection.addImage(
        "https://cdn.pixabay.com/photo/2018/05/08/21/29/windows-3384024_960_720.png",
        ititle="Windows",
    )
    myMessageSection.addImage(
        "https://pics.freeicons.io/uploads/icons/png/3525127881551941184-512.png",
        ititle="Linux",
    )

    # myTeamsMessage.addLinkButton("Start", actionbutton)


    # Add your section to the connector card object before sending
    myTeamsMessage.addSection(myMessageSection)

    myTeamsMessage.addPotentialAction(myTeamsPotentialAction3)

    myTeamsMessage.addPotentialAction(potential_add_whitelist_user)


    if result_link != None:
        result_Link=str(result_link).replace("localhost.localdomain","192.168.135.170")
        print(result_Link)
        myTeamsMessage.addLinkButton("Xem kết quả ", result_Link)

    myTeamsMessage.send()
    return myTeamsMessage.last_http_response.status_code