import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "lib"))
import splunklib.client as client
import splunklib.results as results
import json


def connect_to_splunk(
    username,
    password,
    host="127.0.0.1",
    port="8089",
    owner="admin",
    app="AD-Adaptive-Response",
    sharing="user",
):
    try:
        service = client.connect(
            host=host,
            port=port,
            username=username,
            password=password,
            owner=owner,
            app=app,
            sharing=sharing,
        )
        if service:
            print("Splunk service created successfully")
            print("------------------------------------")
        return service
    except Exception as e:
        print(e)


def run_normal_mode_search(splunk_service, search_string, payload={}):
    try:
        job = splunk_service.jobs.create(search_string, **payload)
        # print(job.content)
        while True:
            while not job.is_ready():
                pass
            if job["isDone"] == "1":
                break
        for result in results.ResultsReader(job.results()):
            return result

    except Exception as e:
        return e


def send_search_to_splunk( status, host,group, user, webhook, token):
   
    if status == "disable":
        search_string = (
            f'''|adenableuser  ad_host="{host}"  user="{user}" webhook="{webhook}" token="{token}" group="{group}"  '''
        )

    else:
        search_string = (
            f''' |addisableuser  ad_host="{host}"  user="{user}" webhook="{webhook}" token="{token}" group="{group}" '''
        )
    return search_string


def main():
    try:
        splunk_service = connect_to_splunk(username="admin", password="Admin@123!")

        search_string = (
            '| adenableuser  ad_host="192.168.135.169" domain="htc.com" user="adam" webhook="CP" token="eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE2NTY1ODAzODIsInN1YiI6Imh1eSJ9.iO4nGfHq696ctjlozKUuWmQf0ISNdzw3C5BhlS146Mc" '
        )
        payload = {"exec_mode": "normal"}
        run_normal_mode_search(splunk_service, search_string, payload)
    except Exception as e:
        print(e)


if __name__ == "__main__":
    main()
