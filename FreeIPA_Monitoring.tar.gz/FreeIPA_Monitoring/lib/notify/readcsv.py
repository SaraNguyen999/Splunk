import csv

def readcsv(path_csv,name):
    result=[]
    with open(path_csv) as f:
        reader=csv.reader(f)   
        for row in reader:
            if(row[0]in name ):
                return row[1]
def checkwhitelist(path_csv, ip):
    with open(path_csv) as f:
        reader = csv.reader(f)
        for row in reader:
            if row[0]==ip:  
                return True
    
    return False