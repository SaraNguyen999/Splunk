import sys, os


sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "lib"))
from typing import Union
from const import *

from fastapi import FastAPI, Request, status
from fastapi import FastAPI, Depends, HTTPException
from fastapi.responses import JSONResponse

from ldap3 import Server, Connection, ALL
from engine.utils import is_disable, is_user

from notify.readcsv import *
import uvicorn
from pydantic import BaseModel
#from jwt_auth.auth import *

"""
    COMMAND SERVER CONTROL USER
- Disable/enable user

"""
class Item(BaseModel):
    host: Union[str, None] = None
    user: Union[str, None] = None
    status: Union[str, None] = None
    password:Union[str, None] = None
    token:Union[str, None] = None

app = FastAPI()
#logger = setup_logger()
#auth_handler = AuthHandler()

users = []

@app.post("/message/")
def send_message(mes):
    #Các lệnh thực thi
    message = mes
    return {"message": message}

@app.post("/disuser/")
def disable_user(item:Item):
    try:
        server= Server(host=item.host,port=389, get_info=ALL)
        conn = Connection(server, 
                        user=DEFAULT_USER,
                        password = item.password,
                        auto_bind=True)
    except Exception as e:
        print("Can't connection to server" + str(e))
    output = conn.modify(item.user, {'nsaccountlock': [('MODIFY_REPLACE', [True])]})
    return output

@app.post("/enuser/")
def disable_user(item:Item):
    try:
        server= Server(host=item.host,port=389, get_info=ALL)
        conn = Connection(server, 
                        user=DEFAULT_USER,
                        password = item.password,
                        auto_bind=True)
    except Exception as e:
        print("Can't connection to server" + str(e))
    output = conn.modify(item.user, {'nsaccountlock': [('MODIFY_REPLACE', [False])]})
    return output

if __name__ == "__main__": 
    uvicorn.run(app, host="0.0.0.0", port=44444)